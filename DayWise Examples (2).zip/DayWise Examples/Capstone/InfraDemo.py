"""
Infrastructure Health Check Dashboard

Prerequisite:
pip install psutil
"""

import psutil
import csv
from datetime import datetime

# ==========================================
# Collect System Health Information
# ==========================================

cpu_usage = psutil.cpu_percent(interval=1)

memory_usage = psutil.virtual_memory().percent

disk_usage = psutil.disk_usage("C:\\").percent

# ==========================================
# Check Windows Service Status
# ==========================================

service_name = "Spooler"
service_status = "Not Found"

for service in psutil.win_service_iter():

    if service.name().lower() == service_name.lower():

        service_status = service.status()

        break


# ==========================================
# Current Timestamp
# ==========================================

current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# ==========================================
# Generate CSV Report
# ==========================================

with open("HealthReport.csv", "w", newline="") as file:

    writer = csv.writer(file)

    writer.writerow(["Metric", "Value"])

    writer.writerow(["Date Time", current_time])
    writer.writerow(["CPU Usage %", cpu_usage])
    writer.writerow(["Memory Usage %", memory_usage])
    writer.writerow(["Disk Usage %", disk_usage])
    writer.writerow(["Spooler Service", service_status])

print("CSV Report Generated Successfully")

# ==========================================
# Generate HTML Dashboard
# ==========================================

html_content = f"""

<html>

<head>
    <title>Infrastructure Dashboard</title>
</head>

<body>

    <h1>Infrastructure Health Dashboard</h1>

    <table border="1" cellpadding="10">

        <tr>
            <th>Metric</th>
            <th>Value</th>
        </tr>

        <tr>
            <td>Date Time</td>
            <td>{current_time}</td>
        </tr>

        <tr>
            <td>CPU Usage</td>
            <td>{cpu_usage}%</td>
        </tr>

        <tr>
            <td>Memory Usage</td>
            <td>{memory_usage}%</td>
        </tr>

        <tr>
            <td>Disk Usage</td>
            <td>{disk_usage}%</td>
        </tr>

        <tr>
            <td>Spooler Service Status</td>
            <td>{service_status}</td>
        </tr>

    </table>

</body>

</html>

"""

with open("HealthDashboard.html", "w") as file:

    file.write(html_content)

print("HTML Dashboard Generated Successfully")

# ==========================================
# Display Summary
# ==========================================

print("\n===== HEALTH CHECK SUMMARY =====")

print("Timestamp      :", current_time)
print("CPU Usage      :", cpu_usage, "%")
print("Memory Usage   :", memory_usage, "%")
print("Disk Usage     :", disk_usage, "%")
print("Service Status :", service_status)
