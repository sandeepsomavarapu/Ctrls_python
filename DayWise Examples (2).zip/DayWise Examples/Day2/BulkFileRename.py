import os

folder_path = r"C:\Logs\Demologs"

count = 1

for filename in os.listdir(folder_path):

    old_path = os.path.join(folder_path, filename)

    # Skip folders
    if os.path.isdir(old_path):
        continue

    extension = os.path.splitext(filename)[1]

    new_name = f"File_{count}{extension}"

    new_path = os.path.join(folder_path, new_name)

    os.rename(old_path, new_path)

    count += 1

print("Files renamed successfully.")