import shutil
import os
from datetime import datetime

source_folder = r"C:\Logs\Applogs"
backup_folder = r"C:\Logs\Backups"

os.makedirs(backup_folder, exist_ok=True)

timestamp = datetime.now().strftime("%H%M%S")

destination = os.path.join(
    backup_folder,
    f"Backup_{timestamp}"
)

shutil.copytree(source_folder, destination)

print("Backup completed successfully!")
print("Backup Location:", destination)