"""
Windows Administration Using Python

Prerequisite:
pip install psutil
"""

import os
import platform
import subprocess
import psutil

print("=" * 60)
print("WINDOWS ADMINISTRATION USING PYTHON")
print("=" * 60)

# --------------------------------------------------
# 1. Display System Information
# --------------------------------------------------

print("\n1. SYSTEM INFORMATION")
print("-" * 30)

print("Operating System :", platform.system())
print("OS Version       :", platform.version())
print("Machine Type     :", platform.machine())
print("Processor        :", platform.processor())

# --------------------------------------------------
# 2. Display CPU Information
# --------------------------------------------------

print("\n2. CPU USAGE")
print("-" * 30)

cpu_usage = psutil.cpu_percent(interval=1)

print("CPU Usage :", cpu_usage, "%")

# --------------------------------------------------
# 3. Display Memory Information
# --------------------------------------------------

print("\n3. MEMORY USAGE")
print("-" * 30)

memory = psutil.virtual_memory()

print("Total Memory :", round(memory.total / (1024**3), 2), "GB")
print