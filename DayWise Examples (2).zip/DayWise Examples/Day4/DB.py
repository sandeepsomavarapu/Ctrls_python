# SQLite comes with Python
import sqlite3

# Connect to database
connection = sqlite3.connect("employee.db")

# Create cursor object
cursor = connection.cursor()

# Create table
cursor.execute("""
CREATE TABLE IF NOT EXISTS employee(
    id INTEGER PRIMARY KEY,
    name TEXT,
    salary REAL
)
""")

# Insert records
cursor.execute("""
INSERT INTO employee(name,salary)
VALUES('Sandeep',75000)
""")

cursor.execute("""
INSERT INTO employee(name,salary)
VALUES('Rahul',65000)
""")

# Save changes
connection.commit()

# Execute query
cursor.execute("SELECT * FROM employee")

# Display results
for row in cursor.fetchall():
    print(row)

# Close connection
connection.close()