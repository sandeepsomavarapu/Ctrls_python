# Import built-in module for IP validation
import ipaddress

# Get IP address from user
ip = input("Enter IP Address: ")

try:
    # Validate IP address
    ipaddress.ip_address(ip)

    print("Valid IP Address")

except ValueError:
    print("Invalid IP Address")