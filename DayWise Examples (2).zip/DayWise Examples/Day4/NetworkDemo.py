# Module to execute OS commands
import subprocess

# Server to check connectivity
host = "google.com"

# Execute ping command
result = subprocess.run(
    ["ping", "-n", "4", host],
    capture_output=True,
    text=True
)

# Display output
print(result.stdout)