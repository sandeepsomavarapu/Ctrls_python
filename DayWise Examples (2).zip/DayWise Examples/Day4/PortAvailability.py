# Used for network communication
import socket

# Target machine
target = "127.0.0.1"

# Ports to scan
ports = [21, 22, 80, 443, 8056,3000, 3306, 5432]

# Loop through each port
for port in ports:

    # Create socket object
    sock = socket.socket(
        socket.AF_INET,
        socket.SOCK_STREAM
    )

    # Check connection
    result = sock.connect_ex((target, port))

    if result == 0:
        print(f"Port {port} OPEN")
    else:
        print(f"Port {port} CLOSED")

    sock.close()