
import importSample
import importSample as ts
from importSample import m1,m2
from importSample import *
importSample.m1()
ts.m2()
m1()
m2()