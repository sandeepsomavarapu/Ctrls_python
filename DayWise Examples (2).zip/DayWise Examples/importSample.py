marks=123

def m1():
    print("am from m1 function")
def m2():
    print("am from m2 function")
print(marks)
m1()    
